#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
#
# Copyright (C) 2022-2025 ImmortalWrt.org

NAME="homeproxy"

RESOURCES_DIR="${RESOURCES_DIR:-/etc/$NAME/resources}"
DASHBOARD_DIR="${DASHBOARD_DIR:-/etc/$NAME/dashboard}"
RUN_DIR="${RUN_DIR:-/var/run/$NAME}"
LOG_PATH="$RUN_DIR/$NAME.log"
RESULT_PATH="$RUN_DIR/update_resources.result"
# Mainland China IP list (plain CIDR text) for the kernel-layer nftables
# bypass. Built daily by MetaCubeX.
CN_IP_SOURCE="${CN_IP_SOURCE:-https://cdn.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@meta/geo/geoip/cn.list}"
# Mainland China domain binary rule-set for sing-box (pre-compiled .srs,
# same MetaCubeX data as the Mihomo .mrs used by Nikki).
GEOSITE_SOURCE="${GEOSITE_SOURCE:-https://cdn.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@sing/geo/geosite/cn.srs}"
DASHBOARD_SOURCE="${DASHBOARD_SOURCE:-https://codeload.github.com/SagerNet/sing-box-dashboard/zip/refs/heads/gh-pages}"
DASHBOARD_VERSION_URL="${DASHBOARD_VERSION_URL:-https://github.com/SagerNet/sing-box-dashboard/commits/gh-pages.atom}"
USER_AGENT="HomeProxy resource updater"
set -o pipefail
UPDATE_PROXY="${HOMEPROXY_UPDATE_PROXY:-}"
SING_BOX="${SING_BOX:-/usr/bin/sing-box}"

if ! mkdir -p "$RESOURCES_DIR" "$DASHBOARD_DIR" "$RUN_DIR"; then
	printf '%s\n' "Failed to prepare HomeProxy resource directories." >&2
	exit 1
fi

log() {
	printf '%s %s\n' "$(date "+%Y-%m-%d %H:%M:%S")" "$*" >> "$LOG_PATH"
}

UPDATED_BRANCHES=""
FAILED_BRANCHES=""
CORE_UPDATED=0
DASHBOARD_UPDATED=0

mark_updated() {
	UPDATED_BRANCHES="${UPDATED_BRANCHES:+$UPDATED_BRANCHES,}$1"
	case "$1" in
	dashboard) DASHBOARD_UPDATED=1 ;;
	cn_ip) ;; # Firewall-only resource, no sing-box reload needed
	*) CORE_UPDATED=1 ;;
	esac
}

mark_failed() {
	FAILED_BRANCHES="${FAILED_BRANCHES:+$FAILED_BRANCHES,}$1"
}

finish() {
	printf 'status=%s\ncore_updated=%s\ndashboard_updated=%s\nupdated=%s\nfailed=%s\n' \
		"$1" "$CORE_UPDATED" "$DASHBOARD_UPDATED" \
		"$UPDATED_BRANCHES" "$FAILED_BRANCHES" > "$RESULT_PATH"
	exit "$1"
}

run_curl() {
	if [ -n "$UPDATE_PROXY" ]; then
		/usr/bin/curl --proxy "$UPDATE_PROXY" "$@"
	else
		/usr/bin/curl "$@"
	fi
}

download() {
	# NOTE: --compressed omitted: Kwrt ships curl without zlib;
	# the unknown option aborts every download (exit 2).
	run_curl -fsSL --retry 3 --retry-all-errors --retry-delay 1 \
		--connect-timeout 10 --max-time 60 -A "$USER_AGENT" -o "$2" "$1" &&
		test -s "$2"
}

validate_rule_set() {
	"$SING_BOX" rule-set match -f binary "$1" 192.0.2.1 >/dev/null 2>&1
}

# MetaCubeX rule data has no release version; track content hash instead.
file_hash() {
	sha256sum "$1" 2>/dev/null | awk '{print $1}'
}

validate_cidr_list() {
	local file="$1"
	[ -s "$file" ] || return 1
	# At least one CIDR with a sane prefix length must exist; this only
	# rules out error pages / truncated downloads. Individual bad lines
	# are skipped with a warning by firewall_pre.uc (load_cidr_file) and
	# must NOT fail the whole update -- a single bad upstream line would
	# otherwise wedge automatic updates forever (fail-closed but stalled).
	awk '
		/^[[:space:]]*(#|$)/ { next }
		{
			line=$0
			sub(/^[[:space:]]+/, "", line)
			sub(/[[:space:]]+$/, "", line)
			n=split(line, p, "/")
			if (n != 2) next
			addr=p[1]; plen=p[2]
			if (plen !~ /^[0-9]+$/) next
			if (index(addr, ":") > 0) {
				if (plen+0 <= 128) { ok=1; exit }
			} else {
				if (plen+0 <= 32) { ok=1; exit }
			}
		}
		END { exit !ok }
	' "$file"
}

fetch_dashboard_version() {
	local feed version

	feed="$(run_curl -fsSL --retry 3 --retry-all-errors \
		--retry-delay 1 --connect-timeout 10 --max-time 30 \
		-A "$USER_AGENT" "$DASHBOARD_VERSION_URL")" || return 1
	version="$(printf '%s\n' "$feed" | awk -F '[<>]' '
		/<updated>/ {
			version = $3
			gsub(/[-:TZ]/, "", version)
			print version
			exit
		}
	')"
	case "$version" in
	??????????????) case "$version" in *[!0-9]*) return 1 ;; esac ;;
	*) return 1 ;;
	esac
	printf '%s\n' "$version"
}

install_resource() {
	local source_file="$1" version="$2" resource="$3" ext="$4"
	local stage_dir="$RESOURCES_DIR/.update.$$.tmp"

	mkdir -p "$stage_dir" &&
		cp "$source_file" "$stage_dir/$resource.$ext" &&
		printf '%s\n' "$version" > "$stage_dir/$resource.ver" &&
		chmod 0644 "$stage_dir/$resource.$ext" "$stage_dir/$resource.ver" &&
		mv -f "$stage_dir/$resource.$ext" "$RESOURCES_DIR/$resource.$ext" || return 1
	mark_updated "$resource"
	# For cn_ip, defer the .ver commit until AFTER the firewall refresh
	# succeeds. This closes the kill window where a SIGKILL between install
	# and firewall refresh would leave new .ver + old firewall, causing the
	# next run to skip the refresh (hash already matches).
	if [ "$resource" = "cn_ip" ] && [ "$CN_IP_DEFER_VER" = "1" ]; then
		DEFERRED_CN_IP_VER="$stage_dir/cn_ip.ver"
		log "[cn_ip] .ver commit deferred until firewall refresh completes."
	else
		mv -f "$stage_dir/$resource.ver" "$RESOURCES_DIR/$resource.ver"
	fi
}

update_hashed_resource() {
	local resource="$1" source_url="$2" ext="$3" validator="$4"
	local new_hash old_hash short

	if ! download "$source_url" "$TMP_DIR/$resource.$ext"; then
		log "[$resource] Update failed while downloading."
		return 1
	fi
	if ! "$validator" "$TMP_DIR/$resource.$ext"; then
		log "[$resource] Update failed: downloaded file did not pass validation."
		return 1
	fi
	new_hash="$(file_hash "$TMP_DIR/$resource.$ext")"
	if [ -z "$new_hash" ]; then
		log "[$resource] Update failed: cannot hash the downloaded file."
		return 1
	fi
	old_hash="$(cat "$RESOURCES_DIR/$resource.ver" 2>/dev/null)"
	if [ "$new_hash" = "$old_hash" ] && [ -s "$RESOURCES_DIR/$resource.$ext" ]; then
		short="$(printf '%s' "$new_hash" | cut -c1-12)"
		log "[$resource] Already up to date ($short)."
		return 0
	fi
	log "[$resource] Local version: ${old_hash:-NOT FOUND}, latest version: $(printf '%s' "$new_hash" | cut -c1-12)."
	if ! install_resource "$TMP_DIR/$resource.$ext" "$new_hash" "$resource" "$ext"; then
		log "[$resource] Update failed while installing."
		return 1
	fi
	log "[$resource] Successfully updated."
}

versioned_url() {
	case "$1" in
	http://*|https://*) printf '%s?v=%s' "$1" "$2" ;;
	*) printf '%s' "$1" ;;
	esac
}

update_dashboard() {
	local version old_version index source_dir=""
	local backup_dir="${DASHBOARD_DIR}.old.$$"

	if ! version="$(fetch_dashboard_version)"; then
		log "[dashboard] Failed to get the latest version; continuing with other resources."
		return 1
	fi
	old_version="$(cat "$DASHBOARD_DIR/dashboard.ver" 2>/dev/null)"
	if [ "$old_version" = "$version" ] && [ -s "$DASHBOARD_DIR/index.html" ]; then
		log "[dashboard] Current version: $version."
		return 0
	fi
	log "[dashboard] Local version: ${old_version:-NOT FOUND}, latest version: $version."
	if ! download "$(versioned_url "$DASHBOARD_SOURCE" "$version")" "$TMP_DIR/dashboard.zip"; then
		log "[dashboard] Update failed while downloading the dashboard."
		return 1
	fi
	if ! unzip -q "$TMP_DIR/dashboard.zip" -d "$TMP_DIR/dashboard"; then
		log "[dashboard] Update failed while extracting the dashboard."
		return 1
	fi
	for index in "$TMP_DIR/dashboard/index.html" "$TMP_DIR"/dashboard/*/index.html; do
		if [ -s "$index" ]; then
			source_dir="${index%/index.html}"
			break
		fi
	done
	if [ -z "$source_dir" ]; then
		log "[dashboard] Update failed: invalid dashboard archive."
		return 1
	fi
	if ! mkdir -p "$DASHBOARD_STAGE" ||
	   ! cp -a "$source_dir/." "$DASHBOARD_STAGE/" ||
	   ! rm -f "$DASHBOARD_STAGE/.etag" ||
	   ! printf '%s\n' "$version" > "$DASHBOARD_STAGE/dashboard.ver" ||
	   ! chmod -R a+rX "$DASHBOARD_STAGE"; then
		log "[dashboard] Update failed while staging the dashboard."
		return 1
	fi
	if ! mv "$DASHBOARD_DIR" "$backup_dir"; then
		log "[dashboard] Update failed while backing up the dashboard."
		return 1
	fi
	if ! mv "$DASHBOARD_STAGE" "$DASHBOARD_DIR"; then
		mv "$backup_dir" "$DASHBOARD_DIR" || log "[dashboard] Unable to restore the dashboard; backup retained at $backup_dir."
		log "[dashboard] Update failed: unable to replace dashboard files."
		return 1
	fi
	rm -rf "$backup_dir"
	mark_updated "dashboard"
	log "[dashboard] Successfully updated."
}

exec 9>"$RUN_DIR/update_resources.lock"
if ! flock -n 9 >/dev/null 2>&1; then
	log "[RESOURCES] A task is already running."
	exit 2
fi
rm -f "$RESULT_PATH"

TMP_DIR="$(mktemp -d "$RUN_DIR/resources-update.XXXXXX")" || {
	log "[RESOURCES] Failed to prepare the temporary update directory."
	finish 1
}
DASHBOARD_STAGE="${DASHBOARD_DIR}.new.$$"
trap 'rm -rf "$TMP_DIR" "$DASHBOARD_STAGE" "$RESOURCES_DIR/.update.$$.tmp"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# Backup current cn_ip data BEFORE attempting update, so a failed
# firewall refresh can restore the previous working data atomically.
cn_ip_list="$RESOURCES_DIR/cn_ip.list"
cn_ip_ver="$RESOURCES_DIR/cn_ip.ver"
cn_ip_list_bak="$RESOURCES_DIR/cn_ip.list.bak"
cn_ip_ver_bak="$RESOURCES_DIR/cn_ip.ver.bak"
[ -f "$cn_ip_list" ] && { cp -f "$cn_ip_list" "$cn_ip_list_bak" || log "[RESOURCES] WARN: failed to backup cn_ip.list (disk full?)"; }
[ -f "$cn_ip_ver" ] && { cp -f "$cn_ip_ver" "$cn_ip_ver_bak" || log "[RESOURCES] WARN: failed to backup cn_ip.ver (disk full?)"; }
# Rule-sets no longer used by the two-path routing (domain list + CN IPs
# in nftables); drop copies left by older versions.
rm -f "$RESOURCES_DIR/geosite_noncn.srs" "$RESOURCES_DIR/geosite_noncn.ver" \
	"$RESOURCES_DIR/geoip_cn.srs" "$RESOURCES_DIR/geoip_cn.ver"
# Defer cn_ip .ver commit until firewall refresh succeeds (see install_resource).
CN_IP_DEFER_VER=1
update_hashed_resource "cn_ip" "$CN_IP_SOURCE" "list" "validate_cidr_list" || mark_failed "cn_ip"
CN_IP_DEFER_VER=0
update_hashed_resource "geosite_cn" "$GEOSITE_SOURCE" "srs" "validate_rule_set" || mark_failed "geosite_cn"
update_dashboard || mark_failed "dashboard"

if [ -n "$FAILED_BRANCHES" ]; then
	if [ -n "$UPDATED_BRANCHES" ]; then
		log "[RESOURCES] Partially updated ($UPDATED_BRANCHES); failed branches: $FAILED_BRANCHES."
		finish 4
	fi
	log "[RESOURCES] Update failed for: $FAILED_BRANCHES."
	finish 1
fi

if [ -z "$UPDATED_BRANCHES" ]; then
	log "[RESOURCES] You're already at the latest version."
	finish 3
fi

# Refresh firewall rules if CN IPs were updated (nftables embeds the CIDRs).
# The generated include is syntax-checked with nft --check before reloading.
# Note: --check is a userspace dry-run and cannot detect kernel-side EEXIST
# errors from duplicate set elements; duplicates are eliminated earlier by
# load_cidr_file()'s normalized dedup in firewall_pre.uc. A broken include
# aborts the entire fw4 reload and would leave the firewall (and the
# transparent proxy) down, as happened with a duplicate-laden upstream list.
# On any failure the previous working include AND the previous data files
# are restored, so the daemon never sees a half-applied update and won't
# trigger a bad service reload.
case "$UPDATED_BRANCHES" in
	*cn_ip*)
		log "[RESOURCES] cn_ip updated, refreshing firewall rules."
		client_nft="$RUN_DIR/fw4_client.nft"
		client_nft_bak="$RUN_DIR/fw4_client.nft.bak"
		[ -f "$client_nft" ] && { cp -f "$client_nft" "$client_nft_bak" || log "[RESOURCES] WARN: failed to backup fw4_client.nft (disk full?)"; }
		if ucode "/etc/homeproxy/scripts/firewall_pre.uc" 2>&1 | tee -a "$LOG_PATH" &&
		   fw4 print 2>&1 | tee -a "$LOG_PATH" | nft --check -f - 2>&1 | tee -a "$LOG_PATH" &&
		   fw4 reload 2>&1 | tee -a "$LOG_PATH"; then
			log "[RESOURCES] Firewall reloaded."
			# Commit the deferred cn_ip .ver now that firewall is in sync.
			if [ -n "$DEFERRED_CN_IP_VER" ] && [ -f "$DEFERRED_CN_IP_VER" ]; then
				mv -f "$DEFERRED_CN_IP_VER" "$cn_ip_ver" && log "[RESOURCES] cn_ip version committed."
			fi
			rm -f "$client_nft_bak" "$cn_ip_list_bak" "$cn_ip_ver_bak"
		else
			log "[RESOURCES] Firewall update failed; restoring previous rules and data."
			[ -f "$cn_ip_list_bak" ] && cp -f "$cn_ip_list_bak" "$cn_ip_list"
			[ -f "$cn_ip_ver_bak" ] && cp -f "$cn_ip_ver_bak" "$cn_ip_ver"
			if [ -f "$client_nft_bak" ]; then
				cp -f "$client_nft_bak" "$client_nft"
				if fw4 reload >/dev/null 2>&1; then
					log "[RESOURCES] Previous firewall rules restored."
				else
					log "[RESOURCES] CRITICAL: failed to restore firewall rules."
					rm -f "$client_nft_bak" "$cn_ip_list_bak" "$cn_ip_ver_bak"
					finish 2
				fi
				rm -f "$client_nft_bak" "$cn_ip_list_bak" "$cn_ip_ver_bak"
			fi
		fi
		;;
esac

finish 0
