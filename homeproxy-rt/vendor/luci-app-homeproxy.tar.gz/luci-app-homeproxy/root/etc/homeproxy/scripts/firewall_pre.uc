#!/usr/bin/ucode

'use strict';

import { readfile, writefile } from 'fs';
import { cursor } from 'uci';
import { HP_DIR, RUN_DIR, normalizeList } from 'homeproxy';

const cfgname = 'homeproxy';
const uci = cursor();
uci.load(cfgname);

let input = [];
if (getenv('HOMEPROXY_SERVER_READY') === '1')
	uci.foreach(cfgname, 'server', (server) => {
		if (server.enabled !== '1' || server.firewall !== '1')
			return;

		const network = server.network || '{ tcp, udp }';
		push(input, `meta l4proto ${network} th dport ${server.port} counter accept comment "!${cfgname}: accept server ${server['.name']}"`);
	});

const input_file = RUN_DIR + '/fw4_input.nft';

if (writefile(input_file, length(input) ? join('\n', input) + '\n' : '') === null)
	exit(1);

/* Transparent proxy (redirect + tproxy) nftables rules.
 *
 * Included into the fw4 table via a table-post include
 * (/var/run/homeproxy/fw4_client.nft). Rule order inside each chain:
 *   1. sing-box's own sockets (routing_mark) bypass everything
 *   2. reserved / private / multicast addresses bypass
 *   3. manually configured WAN direct destinations bypass
 *   4. mainland China IPs bypass in the kernel, never reaching sing-box
 *   5. everything else goes to the transparent proxy
 *
 * Only generated when the client instance is enabled; in server-only
 * mode the include stays empty so no traffic is intercepted.
 */

// Client is enabled if main_node is set (uci.get works, no env var needed)
const main_node = uci.get(cfgname, 'config', 'main_node');
const client_enabled = (main_node !== null && main_node !== '' && main_node !== 'nil');

let nft = [];
/* Atomic hot-swap of the mainland sets (used by update_resources.sh):
 * one nft transaction flushes and refills hp_cn4/hp_cn6, so removed
 * CIDRs really disappear (fw4 reload's 'flush table' keeps set
 * elements) and traffic never sees a half-filled set. */
let cn_sets = '';

if (client_enabled) {
const redirect_port = uci.get(cfgname, 'infra', 'redirect_port') || '5331';
const tproxy_port = uci.get(cfgname, 'infra', 'tproxy_port') || '5332';
const self_mark = uci.get(cfgname, 'infra', 'self_mark') || '100';
const tproxy_mark = uci.get(cfgname, 'infra', 'tproxy_mark') || '101';
const ipv6_support = uci.get(cfgname, 'config', 'ipv6_support') || '0';
const listen_interfaces = normalizeList(uci.get(cfgname, 'control', 'listen_interfaces'));

function normalize_ipv6(addr) {
	/* Lowercase and expand :: to full 8-group form, stripping leading
	 * zeros, so that textual variants of the same address compare equal.
	 * Returns null if unparsable. */
	addr = lc(addr);
	if (match(addr, /\./))
		return addr; /* v4-mapped / v4-compatible: only case-normalized */
	let parts = split(addr, '::');
	let groups = [];
	if (length(parts) == 1) {
		groups = split(parts[0], ':');
	} else if (length(parts) == 2) {
		let left = parts[0] == '' ? [] : split(parts[0], ':');
		let right = parts[1] == '' ? [] : split(parts[1], ':');
		let missing = 8 - length(left) - length(right);
		if (missing < 0)
			return null;
		groups = left;
		for (let i = 0; i < missing; i++)
			push(groups, '0');
		for (let g in right)
			push(groups, g);
	} else {
		return null; /* multiple :: */
	}
	if (length(groups) != 8)
		return null;
	let norm = [];
	for (let g in groups) {
		if (!match(g, /^[0-9a-f]{1,4}$/))
			return null;
		while (length(g) > 1 && substr(g, 0, 1) == '0')
			g = substr(g, 1);
		push(norm, g);
	}
	return join(':', norm);
}

function normalize_cidr(line) {
	/* Canonicalize a CIDR string so textual variants of the same network
	 * dedup to one entry. IPv4: host bits are masked off
	 * (1.1.1.1/24 -> 1.1.1.0/24). IPv6: lowercased and :: expanded.
	 * Returns the canonical "addr/plen" string, or null if invalid
	 * (bad format or prefix length out of range). */
	let parts = split(line, '/');
	if (length(parts) != 2)
		return null;
	if (parts[1] == '' || match(parts[1], /[^0-9]/))
		return null;
	let addr = parts[0], plen = int(parts[1]);
	if (match(addr, /:/)) {
		if (plen < 0 || plen > 128)
			return null;
		let norm = normalize_ipv6(addr);
		if (norm == null)
			return null;
		return `${norm}/${plen}`;
	}
	if (plen < 0 || plen > 32)
		return null;
	let octets = split(addr, '.');
	if (length(octets) != 4)
		return null;
	let ip = 0;
	for (let o in octets) {
		if (match(o, /[^0-9]/) || o == '')
			return null;
		let v = int(o);
		if (v < 0 || v > 255)
			return null;
		ip = ((ip << 8) | v) & 0xFFFFFFFF;
	}
	let mask = plen == 0 ? 0 : ((0xFFFFFFFF << (32 - plen)) & 0xFFFFFFFF);
	ip = (ip & mask) & 0xFFFFFFFF;
	/* >> is sign-propagating; & 0xFF recovers the unsigned octet */
	let b0 = (ip >> 24) & 0xFF;
	let b1 = (ip >> 16) & 0xFF;
	let b2 = (ip >> 8) & 0xFF;
	let b3 = ip & 0xFF;
	return `${b0}.${b1}.${b2}.${b3}/${plen}`;
}

function load_cidr_file(path) {
	const content = readfile(path);
	if (content == null)
		return [];
	let seen = {};
	let result = [];
	for (let line in split(content, '\n')) {
		line = trim(line);
		if (line == '' || substr(line, 0, 1) == '#')
			continue;
		/* Normalize first: textual variants of the same network
		 * (1.1.1.1/24 vs 1.1.1.0/24, 2001:DB8::/32 vs 2001:db8::/32)
		 * would otherwise both reach the kernel, where nftables
		 * rejects the duplicate with EEXIST and aborts the entire
		 * fw4 reload. Note nft --check is a userspace dry-run and
		 * can NOT catch EEXIST; this dedup is the only defense. */
		let norm = normalize_cidr(line);
		if (norm == null) {
			warn(`Skipping invalid CIDR entry: ${line}\n`);
			continue;
		}
		if (seen[norm])
			continue;
		seen[norm] = 1;
		push(result, norm);
	}
	return result;
}

function split_families(cidrs) {
	let v4 = [], v6 = [];
	for (let cidr in cidrs) {
		if (match(cidr, /:/))
			push(v6, cidr);
		else
			push(v4, cidr);
	}
	return [v4, v6];
}

function uci_cidrs(section, options) {
	let result = [];
	for (let option in options) {
		for (let value in normalizeList(uci.get(cfgname, section, option))) {
			value = trim(value);
			if (value == '')
				continue;
			if (!match(value, /\//))
				value += match(value, /:/) ? '/128' : '/32';
			if (match(value, /^[0-9a-fA-F:.]+\/[0-9]{1,3}$/))
				push(result, value);
		}
	}
	return result;
}

function nft_set(name, type, cidrs) {
	let decl = `set ${name} {\n\ttype ${type}\n\tflags interval\n\tauto-merge\n`;
	if (length(cidrs))
		decl += `\telements = { ${join(', ', cidrs)} }\n`;
	decl += '}\n';
	return decl;
}

/* Bypass rules shared by all four transparent-proxy chains. */
function proxy_bypass_rules(is_prerouting, proxy_action) {
	/* Hot path: no per-rule counters, cheapest and most frequent
	 * returns first (mainland destinations are the bulk of traffic). */
	let rules = [];
	push(rules, `\tmeta mark ${self_mark} return`);
	/* Reply packets belong to connections that already exist (e.g. the
	 * HY2 server answering sing-box); never divert them. */
	push(rules, '\tct direction reply return');
	if (is_prerouting && length(listen_interfaces))
		push(rules, `\tiifname != { "${join('", "', listen_interfaces)}" } return`);
	push(rules, '\tip daddr @hp_cn4 return');
	push(rules, '\tip daddr @hp_local4 return');
	push(rules, '\tip daddr @hp_wan_direct4 return');
	if (ipv6_support === '1') {
		push(rules, '\tip6 daddr @hp_cn6 return');
		push(rules, '\tip6 daddr @hp_local6 return');
		push(rules, '\tip6 daddr @hp_wan_direct6 return');
	}
	/* Packets to the router itself (its PPPoE public IP). */
	if (is_prerouting)
		push(rules, '\tfib daddr type local return');
	push(rules, '\tudp dport { 67, 68, 546, 547 } return');
	return rules;
}

function nft_chain(name, hook, prerouting, l4, action) {
	let out = `chain ${name} {\n\t${hook}; policy accept;\n`;
	/* When IPv6 support is off, IPv6 traffic must not enter the proxy
	 * at all: return immediately so it follows normal routing. Without
	 * this, the 'meta l4proto tcp/udp' action below would still capture
	 * IPv6 even though the IPv6 bypass rules are skipped when the switch
	 * is off. */
	if (ipv6_support !== '1')
		out += '\tip version 6 counter return\n';
	/* Each chain only acts on one L4 protocol; let the other one leave
	 * immediately instead of walking every set lookup per packet. */
	out += `\tmeta l4proto != ${l4} return\n`;
	for (let rule in proxy_bypass_rules(prerouting, action))
		out += rule + '\n';
	out += `\t${action}\n}\n`;
	return out;
}

const cn_families = split_families(load_cidr_file(HP_DIR + '/resources/cn_ip.list'));
const wan_direct_families = split_families(uci_cidrs('control', ['wan_direct_ipv4_ips', 'wan_direct_ipv6_ips']));

push(nft, nft_set('hp_cn4', 'ipv4_addr', cn_families[0]));
cn_sets += 'flush set inet fw4 hp_cn4\n';
if (length(cn_families[0]))
	cn_sets += `add element inet fw4 hp_cn4 { ${join(', ', cn_families[0])} }\n`;
push(nft, nft_set('hp_wan_direct4', 'ipv4_addr', wan_direct_families[0]));
push(nft, nft_set('hp_local4', 'ipv4_addr',
	['127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '169.254.0.0/16', '224.0.0.0/4', '255.255.255.255/32']));
/* IPv6 sets are only needed when IPv6 proxying is enabled; skip them
 * otherwise to save memory (each set with elements costs kernel memory). */
if (ipv6_support === '1') {
	push(nft, nft_set('hp_cn6', 'ipv6_addr', cn_families[1]));
	cn_sets += 'flush set inet fw4 hp_cn6\n';
	if (length(cn_families[1]))
		cn_sets += `add element inet fw4 hp_cn6 { ${join(', ', cn_families[1])} }\n`;
	push(nft, nft_set('hp_wan_direct6', 'ipv6_addr', wan_direct_families[1]));
	push(nft, nft_set('hp_local6', 'ipv6_addr',
		['::1/128', 'fc00::/7', 'fe80::/10', 'ff00::/8']));
}

/* TCP: LAN clients and router-local traffic via nftables redirect. */
push(nft, nft_chain('hp_redirect_pre',
	'type nat hook prerouting priority dstnat', true, 'tcp',
	`meta l4proto tcp redirect to :${redirect_port}`));
push(nft, nft_chain('hp_redirect_out',
	'type nat hook output priority dstnat', false, 'tcp',
	`meta l4proto tcp redirect to :${redirect_port}`));

/* UDP: LAN clients via TPROXY; router-local traffic is marked here and
 * picked up by the fwmark policy route (see init.d) into the TPROXY socket. */
push(nft, nft_chain('hp_tproxy_pre',
	'type filter hook prerouting priority mangle', true, 'udp',
	`meta l4proto udp meta mark set ${tproxy_mark} tproxy to :${tproxy_port} accept`));
push(nft, nft_chain('hp_tproxy_out',
	'type route hook output priority mangle', false, 'udp',
	`meta l4proto udp meta mark set ${tproxy_mark}`));

} /* if (client_enabled) */

if (writefile(RUN_DIR + '/fw4_cn_sets.nft', cn_sets) === null)
	exit(1);

const client_file = RUN_DIR + '/fw4_client.nft';
if (writefile(client_file, length(nft) ? join('\n', nft) + '\n' : '') === null)
	exit(1);

